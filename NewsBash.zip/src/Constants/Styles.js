export const MenuItemsStyle = {
    color: 'white',
    textDecoration:'none',
    marginRight: '20px',
    textTransform: 'capitalize'
}