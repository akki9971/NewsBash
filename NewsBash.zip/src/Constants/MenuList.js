export const MenuList = [
    "general",
    "health",
    "entertainment",
    "sports",
    "science",
    "business",
    "technology"
]

