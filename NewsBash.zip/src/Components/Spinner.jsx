import React, { Component } from 'react'
import loader from '../loader.gif'
import CardMedia from '@mui/material/CardMedia';
import Card from '@mui/material/Card';

export class Spinner extends Component {
    render() {
        return (
            <Card sx={{ maxWidth: 200 , display:'flex', margin: 'auto'}}>
                <CardMedia
                    component="img"
                    height="200"
                    image={loader}
                    alt="loader">

                </CardMedia>
            </Card>
        )
    }
}

export default Spinner
