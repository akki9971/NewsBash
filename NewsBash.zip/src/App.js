import './App.css';
import {MainApp} from './Components';

function App() {
  return (
    <div className="App">
      <MainApp />
    </div>
  );
}

export default App;
